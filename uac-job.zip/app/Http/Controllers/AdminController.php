<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Offre;
use App\Models\User;

class AdminController extends Controller
{
    //
    public function adminoffre() {

        $offres = Offre::all();

        return view('pages.adminoffre',compact('offres'));
    }

    public function adminactualite() {
        return view('pages.adminactualite');
    }

    public function addoffre(Request $request) {
        $request->validate([
            'domaine'=>'required',
            'employeur'=>'required',
            'duree'=>'required',
            'description'=>'required',
            'type'=>'required',
        ]);
        
        Offre::create([
            'domaine'=>$request->domaine,
            'employeur'=>$request->employeur,
            'duree'=>$request->duree,
            'description'=>$request->description,
            'type'=>$request->type,
        ]);

        return redirect()->back();
    }

    public function activeroffre() {
        $offres = Offre::all();

        return view('pages.activeoffre',compact('offres'));
    }

    public function activationoffre($id) {
        Offre::find($id)->update(['etat'=>true]);

        return redirect()->back();  
    }

    public function supprimeroffre($id) {
        Offre::find($id)->delete();

        return redirect()->back();  
    }


    public function activercompte() {
        $users = User::all();

        return view('pages.activecompte',compact('users'));
    }

    public function activationcompte($id) {
        User::find($id)->update(['etat'=>true]);
        
        return redirect()->back();  
    }


}
