<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Offre;

class EtudiantController extends Controller
{
    public function index() {

        $offres = Offre::limit(6)->get();

        return view('accueil',compact('offres'));
    }

    public function loginRegister() {
        return view('pages.connexion');
    }

    public function Opportunite() {

        $offres = Offre::all();

        // dd($emploi);

        return view('pages.offres',compact('offres'));
    }

    public function Ressource() {

        $offres = Offre::all();

        // dd($emploi);

        return view('pages.education',compact('offres'));
    }
}
