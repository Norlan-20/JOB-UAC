<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Models\User;

class LoginController extends Controller
{
    //
    public function loginRegister() {
        return view('pages.connexion');
    }


    // Registration

    public function register(Request $request) {
        $request->validate([
            'name'=>'required',
            'mail'=>'required|email|unique:users,email',
            'type'=>'required',
            'pass1'=>'min:8|required',
            'pass2'=>'required'
        ]);

        if($request->pass1 == $request->pass2)
        {
            $pass = Hash::make($request->pass1);
            User::create([
                'name'=>$request->name,
                'email'=>$request->mail,
                'type'=>$request->type,
                'password'=>$pass
            ]);

            return redirect()->route('accueil');
        }

        return back()->withErrors('Les Mots de passe ne correspondent pas');
    }

    //Authentication

    public function login(Request $request) {

        $request->validate([
            'mail'=>'email|required',
            'pass'=>'required'
        ]);

        // dd(bcrypt('topsecret'));

        // $credentials = $request->only('email','password');

        if(Auth::attempt(['email' => $request->mail, 'password' => $request->pass])) {
            $request->session()->regenerate();

            $user = User::where('id',Auth::id())->get();

            session(['user'=>$user]);

            $result = session('user');

            if($result[0]['type']=='Employeur')
                return redirect()->route('accueil');
            elseif($result[0]['type']=='Etudiant')
                return redirect()->route('offre');
            else
                return redirect()->route('adminoffre');
        }
        // else if (Auth::guard('admin')->attempt(['email' => $request->mail, 'password' => $request->pass])) {
        //     return redirect()->route('adminoffre');
        // }

        return back();

    }

    // Logout function
    public function logout(Request $request) {

        Auth::logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();

        return redirect()->route('accueil');

    }

}


