<?php $result = session('user'); ?>
@if(Auth::check() && $result[0]['type']=='Admin')

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href=" {{ asset('css/dashboard.css') }} ">
    <link rel="stylesheet" href=" {{ asset('css/font.css') }} ">
    <link rel="stylesheet" href=" {{ asset('font/icomoon/style.css') }} ">
    <title>Admin Panel | @yield('title')</title>
</head>

<?php
    $etudiant = App\Models\User::where('type','Etudiant')->count();
    $employeur = App\Models\User::where('type','Employeur')->count();
    $stage = App\Models\Offre::where('type','Stage')->count();
    $emploi = App\Models\Offre::where('type','Emploi')->count();
?>
<body>
    <main>
        <div>
            <ul>
                <li><a href=" {{ route('adminoffre') }} "><i class="icon-add_circle"></i> Offre</a></li>
                <li><a href=" {{ route('adminactualite') }} "><i class="icon-add_circle"></i> Actualité</a></li>
                <li><a href=" {{ route('activeroffre') }} "><i class="icon-check-circle-o"></i> Activer une offre</a></li>
                <li><a href=" {{ route('activercompte') }} "><i class="icon-check-circle-o"></i> Activer un compte</a></li>
                <li><a href=""><i class="icon-message"></i> Chat</a></li>
                <li><a href=""><i class="icon-message"></i> Newsletter</a></li>
                <li><a href=""><i class="icon-settings"></i> Outils</a></li>
            </ul>
            <p><a href=" {{ route('logout') }} "><i class="icon-power-off"></i> Deconnexion</a></p>
        </div>
        <div>
            <div class="barre">
                <i class="icon-search"></i>
               <p> <i class="icon-user-o"></i> Admin User</p>
            </div>
            <div class="stat">
                <div id="etudiant">
                    <p><i class="icon-user"></i>Etudiant</p>
                    <p> {{ $etudiant }} </p>
                </div>
                <div id="employeur">
                    <p><i class="icon-group"></i>Employeur</p>
                    <p> {{ $employeur }} </p>
                </div>
                <div id="stage">
                    <p><i class="icon-assignment_ind"></i>Stage</p>
                    <p> {{ $stage }} </p>
                </div>
                <div id="emploi">
                    <p><i class="icon-briefcase"></i>Emploi</p>
                    <p> {{ $emploi }} </p>
                </div>
            </div>

            <div id="body">
                <div>
                    @yield('maincontent')
                </div>
            </div>
        </div>
    </main>

        @yield('js')

</body>
</html>

@else
    {!! redirect()->route('accueil') !!}
@endif
