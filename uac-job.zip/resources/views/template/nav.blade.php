    {{--  nav code  --}}
    <nav class="main-nav">
        <h3><a href="{{ route('accueil') }}">UAC-Job</a></h3>
        <div class="link">
            <a class="active" href=" {{ route('accueil') }} ">Accueil</a>
            <a href=" {{ route('offre') }} ">Opportunités</a>
            <a href=" {{ route('ressource') }}  ">Ressources Educatives</a>
            <a href="" id="partenaire">Partenaire</a>
            <a href="  ">Contact</a>
            <a href="  ">A propos</a>
            @if (Auth::check())
                <a href=" {{ route('logout') }} ">Deconnexion</a>
            @else
                <a href=" {{ route('login') }} ">Connexion</a>
            @endif

        </div>
        <div class="shownav"><i class="icon-menu"></i></div>
    </nav>
    {{--  nav code  --}}
