<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href=" {{ asset('css/accueil.css') }} ">
    <link rel="stylesheet" href=" {{ asset('css/slider.css') }} ">
    <link rel="stylesheet" href=" {{ asset('css/slider.css') }} ">
    <link rel="stylesheet" href=" {{ asset('css/splide.min.css') }} ">
    <link rel="stylesheet" href=" {{ asset('css/font.css') }} ">
    <link rel="stylesheet" href=" {{ asset('css/nav.css') }} ">
    <link rel="stylesheet" href=" {{ asset('font/icomoon/style.css') }} ">
    <title>Accueil | UAC-Job</title>
</head>
<body>

    @include('template.nav')
    {{--  Header code  --}}
    <header>
        {{--  slide1 code  --}}
        <div class="slider slide1">
            <div class="info">
                <h2>Du mal a vous inserer dans le monde professionnel ?</h2>
                <p>Avec UAC-Job accéder à des offres d {{"'"}}emploi et de stages offerte par des entreprises
                    dont vous avez toujours rêver. Allez faites le grand pas et aquérer de l {{"'"}}expérience
                    professionnel afin d {{"'"}}être fier de votre CV.
                </p>
                <a href="">Plus</a>
            </div>
        </div>
        {{--  slide1 code  --}}

        {{--  slide2 code  --}}
        <div class="slider slide2">
            <div class="info">
                <h2>OSEZ Vous Exprimer et laisser opérer votre créativité.</h2>
                <p>
                    Retrouvez le sourire en saisissant les opportunités qui se présente à vous.
                    Laissez parler votre savoir faire et donnez vous toutes les chances de décrocher un emploi bien
                    rémunéré.
                </p>
                <a href="">Plus</a>
            </div>
        </div>
        {{--  slide2 code  --}}

        {{--  slide3 code  --}}
        <div class="slider slide3">
            <div class="info">
                <h2>OSEZ Vous Exprimer et laisser opérer votre créativité.</h2>
                <p>
                    Retrouvez le sourire en saisissant les opportunités qui se présente à vous.
                    Laissez parler votre savoir faire et donnez vous toutes les chances de décrocher un emploi bien
                    rémunéré.
                </p>
                <a href="">Plus</a>
            </div>
        </div>
        {{--  slide3 code  --}}

    </header>
    {{--  header code  --}}

    {{--  section way  --}}

    <div id="main">

        {{--  section1  --}}
        <section>
            <h1><strong>Les actualités</strong></h1>
            <div class="actu">
                <div class="actu1">
                    <div class="illustration illustration1">
                        <img src=" {{asset('img/accueil/header5.jpg')}} " width="100%" height="100%" alt="">
                    </div>
                    <div class="description">
                        <p><span class="title">Info</span></p>
                        <p class="text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quo similique illum laborum aliquid esse sunt nesciunt unde sequi voluptas sed explicabo eaque cumque, eum reprehenderit perspiciatis atque? Rem, a consequatur.</p>
                        <a href="">Lire tout</a>
                    </div>
                </div>
                <div class="actu2">
                    <div class="info info1">
                        <p><img src=" {{ asset('img/da-cruz-recteur-uac-2017.jpg') }} " alt="Recteur UAC"></p>
                        <div>
                            <h3>Recteur UAC</h3>
                            <p><strong class="vert">da-CRUZ Rony</strong>, consectetur adipisicing elit. At dolores laudantium recusan</p>
                        </div>
                    </div>
                    <div class="info info2">
                        <p><img src=" {{ asset('img/patrice-talon.png') }} " alt="Patrice Talon Chef du gouvernent"></p>
                        <div>
                            <h3>Chef du gouvernement</h3>
                            <p><strong class="vert">Patrice Atanase Guillaume TALON</strong>, consectetur adipisicing elit. At dolores laudantium recusan</p>
                        </div>
                    </div>
                    {{--  <div class="info info3"></div>  --}}
                </div>
                {{--  <div class="actu3">
                    <div class="deco deco1"></div>
                    <div class="deco deco2"></div>
                    <div class="deco deco3"></div>
                    <div class="deco deco4"></div>
                </div>  --}}
            </div>
        </section>

        {{--  section2  --}}
        <section class="otherversion">
            <h1><strong>Stages et Emplois</strong></h1>
            <div class="splide" data-splide='{"type":"loop","perPage":3,"autoplay":"true","interval":3000,"perMove":1}'>
                <div class="splide__track">
                    <ul class="splide__list" id="offre">
                        @foreach($offres as $offre)
                            @if($offre->etat)
                            <li class="splide__slide">
                                <h1> {{ $offre->type }} </h1>
                                <p class="affiche">
                                    <img src=" {{asset('img/accueil/5fd4e464b3b3c.jpg')}} "/>
                                </p>
                                <p>Date : {{ $offre->updated_at }} <br> Domaine : {{ $offre->domaine }}</p>
                                <a href=" {{ route('offre') }} ">Voir</a>
                            </li>
                            @endif
                        @endforeach
                    </ul>
                </div>
            </div>

        </section>
{{--
        <section class="mobileversion">
            <h1><strong>Stages et Emplois</strong></h1>
            <div class="splide" data-splide='{"type":"loop","perPage":1,"autoplay":"true","interval":3000,"perMove":1}'>
                <div class="splide__track">
                    <ul class="splide__list" id="offremobile">
                        <li class="splide__slide">
                            <h1>EMPLOI</h1>
                            <p class="affiche">
                                <img src=" {{asset('img/accueil/5fd4e464b3b3c.jpg')}} "/>
                            </p>
                            <p>Date : 20/01/2001 <br> Domaine : Ressources humaines</p>
                            <a href="#">Voir</a>
                        </li>
                        <li class="splide__slide">
                            <h1>STAGE</h1>
                            <p class="affiche">
                                <img src=" {{asset('img/accueil/5fd4e0409f94f.jpg')}} "/>
                            </p>
                            <p>Date : 20/01/2001 <br> Domaine : Bâtiment</p>
                            <a href="#">Voir</a>
                        </li>
                        <li class="splide__slide">
                            <h1>EMPLOI</h1>
                            <p class="affiche">
                                <img src=" {{asset('img/accueil/header2.jpg')}} "/>
                            </p>
                            <p>Date : 20/01/2001 <br> Domaine : Electronique</p>
                            <a href="#">Voir </a>
                        </li>
                        <li class="splide__slide">
                            <h1>STAGE</h1>
                            <p class="affiche">
                                <img src=" {{asset('img/accueil/header2.jpg')}} "/>
                            </p>
                            <p>Date : 20/01/2001 <br> Domaine : Mécanique</p>
                            <a href="#">Voir </a>
                        </li>
                        <li class="splide__slide">
                            <h1>EMPLOI</h1>
                            <p class="affiche">
                                <img src=" {{asset('img/accueil/header2.jpg')}} "/>
                            </p>
                            <p>Date : 20/01/2001 <br> Domaine : Agriculture</p>
                            <a href="#">Voir </a>
                        </li>
                        <li class="splide__slide">
                            <h1>STAGE</h1>
                            <p class="affiche">
                                <img src=" {{asset('img/da-cruz-recteur-uac-2017.jpg')}} "/>
                            </p>
                            <p>Date : 20/01/2001 <br> Domaine : Médeciine</p>
                            <a href="#">Voir </a>
                        </li>
                        <li class="splide__slide">
                            <h1>STAGE</h1>
                            <p class="affiche">
                                <img src=" {{asset('img/accueil/header2.jpg')}} "/>
                            </p>
                            <p>Date : 20/01/2001 <br> Domaine : Informatique</p>
                            <a href="#">Voir </a>
                        </li>
                    </ul>
                </div>
                <div class="splide__progress">
                    <div class="splide__progress__bar">
                    </div>
                </div>
            </div>
        </section>  --}}


        {{--  section3  --}}
        <section>
            <h1><strong>Evènement</strong></h1>
            <div id="evenement">
                <h1>NOËL</h1>
                <p>JOYEUX NOËL A TOUTES ET A TOUS</p>
            </div>
        </section>

        {{--  section4  --}}
        <section>
            <h1><strong>PARTENAIRES</strong></h1>

            </section>
        </section>

    </div>

    {{--  section way  --}}

    {{--  nav for mobile  --}}

    <div id="nav">
        <i class="icon-close"></i>
        <ul>
            <li><a class="active" href=" {{ route('accueil') }} ">Accueil</a></li>
            <li><a href=" {{ route('offre') }} ">Opportunités</a></li>
            <li><a href=" {{ route('ressource') }}  ">Ressources Educatives</a></li>
            <li><a href="" id="partenaire">Partenaire</a></li>
            <li><a href="  ">Contact</a></li>
            <li><a href="  ">A propos</a></li>
            @if (Auth::check())
                <li><a href=" {{ route('logout') }} ">Deconnexion</a></li>
            @else
                <li><a href=" {{ route('login') }} ">Connexion</a></li>
            @endif
        </ul>
    </div>

    {{--  nav for mobile  --}}


    {{--  Footer code  --}}

    <footer>
        Copyright Job-UAC 2020 Tout Droit réservé
    </footer>

    {{--  Drapeau du Bénin  --}}
    <div id="flag">
        <p class="green"></p>
        <p class="yellow"</p>
        <p class="red"></p>
    </div>

    <script src=" {{ asset('js/slide.js') }} "></script>
    <script src=" {{ asset('js/nav.js') }} "></script>
    <script src=" {{ asset('js/splide.min.js') }} "></script>
    <script src=" {{ asset('js/jquery.min.js') }} "></script>
    <script>
        var splide = new Splide( '.splide' );

        splide.on( 'autoplay:play', function ( rate ) {
            console.log( rate ); // 0-1
        } );

        splide.mount();
    </script>
    </body>
</html>
