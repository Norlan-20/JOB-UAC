<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href=" {{ asset('css/font.css') }} ">
    <link rel="stylesheet" href=" {{ asset('css/nav.css') }} ">
    <link rel="stylesheet" href=" {{ asset('css/slider.css') }} ">
    <link rel="stylesheet" href=" {{ asset('css/offre.css') }} ">
    <link rel="stylesheet" href=" {{ asset('font/icomoon/style.css') }} ">
    <title>UAC-Job | Opportunités</title>
</head>
<body>

    @include('template.nav')

    {{--  header code  --}}

    <header>
        <h1>Stage / Emploi</h1>
    </header>

    {{--  header code  --}}

    <div class="para">
        <p>Stage / Emploi</p>
    </div>

    <main>

        @foreach($offres as $offre)
            @if($offre->etat)
                <div class="card">
                    <div>
                        <p> <img src=" {{ asset('img/accueil/header1.jpg') }} " alt=""> </p>
                        <h1> {{ $offre->type }} </h1>
                        <h2><i class="icon-domain"></i> {{ $offre->employeur }} </h2>
                        <p class="desc"> {{ $offre->description }} </p>
                        <p class="hours"><i class="icon-timelapse"></i> {{ $offre->updated_at }} </p>
                    </div>
                    <div>
                        <a href="">Postuler</a>
                    </div>
                </div>
            @endif
        @endforeach

        {{--  <div class="card">
            <div>
                <p>
                    <img src=" {{ asset('img/accueil/header1.jpg') }} " alt="" srcset="">
                </p>
                <h2>
                    EMPLOI
                </h2>
                <h3><i class="icon-domain"></i> JTEK Solution</h3>
                <p class="hours"><i class="icon-timelapse"></i></p>
            </div>
            <div>
                <button>Postuler</button>
            </div>
        </div>
        <div class="card">
            <div>
                <p>
                    <img src=" {{ asset('img/accueil/header1.jpg') }} " alt="" srcset="">
                </p>
                <h2>
                    EMPLOI
                </h2>
                <h3><i class="icon-domain"></i> JTEK Solution</h3>
            </div>
            <div>
                <button>Postuler</button>
            </div>
        </div>
        <div class="card">
            <div>
                <p>
                    <img src=" {{ asset('img/accueil/header1.jpg') }} " alt="" srcset="">
                </p>
                <h2>
                    EMPLOI
                </h2>
                <h3><i class="icon-domain"></i> JTEK Solution</h3>
            </div>
            <div>
                <button>Postuler</button>
            </div>
        </div>
        <div class="card">
            <div>
                <p>
                    <img src=" {{ asset('img/accueil/header1.jpg') }} " alt="" srcset="">
                </p>
                <h2>
                    EMPLOI
                </h2>
                <h3><i class="icon-domain"></i> JTEK Solution</h3>
            </div>
            <div>
                <button>Postuler</button>
            </div>
        </div>
        <div class="card">
            <div>
                <p>
                    <img src=" {{ asset('img/accueil/header1.jpg') }} " alt="" srcset="">
                </p>
                <h2>
                    EMPLOI
                </h2>
                <h3><i class="icon-domain"></i> JTEK Solution</h3>
            </div>
            <div>
                <button>Postuler</button>
            </div>
        </div>
        <div class="card">
            <div>
                <p>
                    <img src=" {{ asset('img/accueil/header1.jpg') }} " alt="" srcset="">
                </p>
                <h2>
                    EMPLOI
                </h2>
                <h3><i class="icon-domain"></i> JTEK Solution</h3>
            </div>
            <div>
                <button>Postuler</button>
            </div>
        </div>  --}}

    </main>

    {{--  nav for mobile  --}}

    <div id="nav">
        <i class="icon-close"></i>
        <ul>
            <li><a class="active" href=" {{ route('accueil') }} ">Accueil</a></li>
            <li><a href=" {{ route('offre') }} ">Opportunités</a></li>
            <li><a href=" {{ route('ressource') }}  ">Ressources Educatives</a></li>
            <li><a href="" id="partenaire">Partenaire</a></li>
            <li><a href="  ">Contact</a></li>
            <li><a href="  ">A propos</a></li>
            @if (Auth::check())
                <li><a href=" {{ route('logout') }} ">Deconnexion</a></li>
            @else
                <li><a href=" {{ route('login') }} ">Connexion</a></li>
            @endif
        </ul>
    </div>

    {{--  nav for mobile  --}}

    <script src=" {{ asset('js/nav.js') }} "></script>
</body>
</html>
