@extends('template.admin')

@section('title', 'Activer Compte')

@section('maincontent')

    <div class="offre2">
        <h2>Activer un compte</h2>
        <table>
            <tr>
                <th>Compte</th>
                <th>Nom</th>
                <th>E-mail</th>
                <th>Etat</th>
                <th>Activer</th>
            </tr>
            @foreach($users as $user)
                <tr>
                    <td> {{ $user['type'] }} </td>
                    <td> {{ $user['name'] }} </td>
                    <td> {{ $user['email'] }} </td>
                    <td>
                        @if($user['etat'])
                            Actif
                        @else
                            Inactif
                        @endif
                    </td>
                    <td> <a href=" {{ route('activationcompte',['id'=>$user['id']]) }} "> <i class="icon-build"></i> </a> </td>
                </tr>
            @endforeach
        </table>
    </div>

@endsection
