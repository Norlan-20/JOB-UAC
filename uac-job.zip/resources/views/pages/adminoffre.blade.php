@extends('template.admin')

@section('title', 'Offre')

@section('maincontent')
    <div>
        <button class="add">Ajouter une offre</button>
        <button class="delete">Modifier / Supprimer une offre</button>
    </div>

    <div class="offre1">
        <h2>Ajouter une offre</h2>
        <form action=" {{ route('addoffre') }}  " method="post">
            <div>
                <div class="input">
                    @csrf
                    <label for="domaine"><i class="icon-user-o"></i></label>
                    <input type="text" name="domaine" id="domaine" placeholder="Informatique par exemple">
                        @error('domaine')
                            {{$message}}
                        @enderror
                </div>
            </div>
            <div>
                <div class="input">
                    @csrf
                    <label for="employeur"><i class="icon-user-o"></i></label>
                    <input type="text" name="employeur" id="employeur" placeholder="Nom de l'entreprise">
                        @error('employeur')
                            {{$message}}
                        @enderror
                </div>
            </div>
            <div>
                <div class="input">
                    <label for="duree"><i class="icon-mail_outline"></i></label>
                    <input type="text" name="duree" id="duree" placeholder="Entrez la durée de l'offre">
                    @error('duree')
                        {{$message}}
                    @enderror
                </div>
            </div>
            <div>
                Description
                <div class="input" style="height: auto;">
                    <label for="description"><i class="icon-mail_outline" style="margin-top: 5px"></i></label>
                    <textarea name="description" id="description" placeholder="Description de l'offre"></textarea>
                    @error('description')
                        {{$message}}
                    @enderror
                </div>
            </div>
            <div>
                <div class="input">
                    <label for="type"><i class="icon-user-secret"></i></label>
                    <select name="type" id="type">
                        <option value="Stage">Stage</option>
                        <option value="Emploi">Emploi</option>
                    </select>
                </div>
            </div>
            <div>
               <button type="submit">S'inscrire'</button><br>
            </div>
        </form>
    </div>

    <div class="offre2" style="display: none;">
        <h2>Modifier / Supprimer offre</h2>
        <table>
            <tr>
                <th>Offre</th>
                <th>Domaine</th>
                <th>Employeur</th>
                <th>Duree</th>
                <th>Etat</th>
                <th>Date</th>
                <th>Modifier</th>
                <th>Supprimer</th>
            </tr>
            @foreach($offres as $offre)
                <tr>
                    <td> {{ $offre['type'] }} </td>
                    <td> {{ $offre['domaine'] }} </td>
                    <td> {{ $offre['employeur'] }} </td>
                    <td> {{ $offre['duree'] }} </td>
                    <td>
                        @if($offre['etat'])
                            Actif
                        @else
                            Inactif
                        @endif
                    </td>
                    <td> {{ $offre['updated_at'] }} </td>
                    <td> <a href="  "> <i class="icon-edit"></i> </a> </td>
                    <td> <a href=" {{ route('supprimeroffre',['id'=>$offre['id']]) }} "> <i class="icon-delete"></i> </a> </td>
                </tr>
            @endforeach
        </table>
    </div>

@endsection

@section('js')
    <script>
        let add = document.querySelector('.add'),
        delet = document.querySelector('.delete'),
        offre1 = document.querySelector('.offre1'),
        offre2 = document.querySelector('.offre2');

        add.addEventListener('click',function(){
            offre1.style.display="block";
            offre2.style.display="none";
        });

        delet.addEventListener('click',function(){
            offre1.style.display="none";
            offre2.style.display="block";
        });
    </script>
@endsection
