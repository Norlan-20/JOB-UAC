@extends('template.admin')

@section('title', 'Offre')

@section('maincontent')
    <div>
        <button>Ajouter une actualité</button>
        <button>Modifier une actualité</button>
        <button>Supprimer une actualité</button>
    </div>

    <div></div>
    <div></div>


@endsection
