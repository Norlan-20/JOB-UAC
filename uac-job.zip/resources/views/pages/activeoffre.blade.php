@extends('template.admin')

@section('title', 'Activer Compte')

@section('maincontent')

    <div class="offre2">
        <h2>Activer une offre</h2>
        <table>
            <tr>
                <th>Offre</th>
                <th>Domaine</th>
                <th>Employeur</th>
                <th>Duree</th>
                <th>Etat</th>
                <th>Date</th>
                <th>Activer</th>
            </tr>
            @foreach($offres as $offre)
                <tr>
                    <td> {{ $offre['type'] }} </td>
                    <td> {{ $offre['domaine'] }} </td>
                    <td> {{ $offre['employeur'] }} </td>
                    <td> {{ $offre['duree'] }} </td>
                    <td>
                        @if($offre['etat'])
                            Actif
                        @else
                            Inactif
                        @endif
                    </td>
                    <td> {{ $offre['updated_at'] }} </td>
                    <td> <a href=" {{ route('activationoffre',['id'=>$offre['id']]) }} "> <i class="icon-build"></i> </a> </td>
                </tr>
            @endforeach
        </table>
    </div>

@endsection
