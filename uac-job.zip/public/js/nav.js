let close = document.querySelector('.icon-close'),
    open = document.querySelector('.icon-menu'),
    mobilenav = document.querySelector('#nav');

    close.addEventListener('click',hidenav);
    open.addEventListener('click',shownav);


    // Show or hide nav

function hidenav(e) {
    mobilenav.classList.add('navhide');
    if(mobilenav.classList.contains('navslide')) {
        mobilenav.classList.remove('navslide');
    }
}

function shownav(e) {
    mobilenav.classList.add('navslide');
    if(mobilenav.classList.contains('navhide')) {
        mobilenav.classList.remove('navhide');
    }
}
