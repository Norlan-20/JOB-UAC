let slide = document.querySelectorAll('.slider'),
    splid = document.querySelector('.otherversion');

var now = 0,next = now+1;
// Au chargement de la page

document.addEventListener('DOMContentLoaded',hideSlide);
document.addEventListener('DOMContentLoaded',resizeSplide);

// Fonction

// Cacher certain slide

function hideSlide() {
    // hide two last slider
    // alert(screen.width);
    for(var i=0; i<slide.length; i++) {
        if(!i) slide[0].style.display="flex";
        else{
            slide[i].style.display="none";
            // slide[1].style.transform="translate(80%)";
        }
    }
    stepbystep();

}

function stepbystep() {
    anime();
}

function anime() {
    setTimeout(function(e){
        slide[now].classList.add('anime');
        slide[now].style.display="none";

        if(now<2) { ++now; }
        else{ now=0; }

        slide[now].style.display="flex";
        slide[now].classList.add('anime1');

        anime();
    },8000);

}

function resizeSplide() {
    if(screen.width <= 768) {
        splid.setAttribute('data-splide','{"type":"loop","perPage":1,"perMove":1}');
    }
    else
        splid.setAttribute('data-splide','{"type":"loop","perPage":3,"autoplay":"true","interval":3000,"perMove":1}');

}
