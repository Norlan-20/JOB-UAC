<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\EtudiantController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\AdminController;
use Illuminate\Auth\Middleware\Authenticate;
use Illuminate\Support\Facades\Auth;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/',[EtudiantController::class,'index'])->name('accueil');

Route::get('/offre',[EtudiantController::class,'Opportunite'])->name('offre');
Route::get('/ressource',[EtudiantController::class,'Ressource'])->name('ressource');

Route::middleware(Authenticate::class)->group(function(){
    Route::get('/adminoffre',[AdminController::class,'adminoffre'])->name('adminoffre');
    Route::get('/adminactualite',[AdminController::class,'adminactualite'])->name('adminactualite');
    Route::get('/activeroffre',[AdminController::class,'activeroffre'])->name('activeroffre');
    Route::get('/supprimeroffre/{id}',[AdminController::class,'supprimeroffre'])->name('supprimeroffre');
    Route::get('/activeroffre/{id}',[AdminController::class,'activationoffre'])->name('activationoffre');
    Route::get('/activercompte',[AdminController::class,'activercompte'])->name('activercompte');
    Route::get('/activationcompte/{id}',[AdminController::class,'activationcompte'])->name('activationcompte');

    Route::post('/addoffre',[AdminController::class,'addoffre'])->name('addoffre');
});


/*
/-------------------------------------------
/ Login Registration
/-------------------------------------------
/
/ Ici nous avons toutes les routes correspondant à l'inscription
/ ainsi que la connexion admin,user,employeur
/
*/

Route::get('/login',[LoginController::class,'loginRegister'])->name('login');

Route::get('/logout',[LoginController::class,'logout'])->name('logout');

Route::post('/registration',[LoginController::class,'register'])->name('register');

Route::post('/loginVerification',[LoginController::class,'login'])->name('authentication');


