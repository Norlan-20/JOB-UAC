<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href=" <?php echo e(asset('css/accueil.css')); ?> ">
    <link rel="stylesheet" href=" <?php echo e(asset('css/slider.css')); ?> ">
    <link rel="stylesheet" href=" <?php echo e(asset('css/slider.css')); ?> ">
    <link rel="stylesheet" href=" <?php echo e(asset('css/splide.min.css')); ?> ">
    <link rel="stylesheet" href=" <?php echo e(asset('css/font.css')); ?> ">
    <link rel="stylesheet" href=" <?php echo e(asset('css/nav.css')); ?> ">
    <link rel="stylesheet" href=" <?php echo e(asset('font/icomoon/style.css')); ?> ">
    <title>Accueil | UAC-Job</title>
</head>
<body>

    <?php echo $__env->make('template.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <header>
        
        <div class="slider slide1">
            <div class="info">
                <h2>Du mal a vous inserer dans le monde professionnel ?</h2>
                <p>Avec UAC-Job accéder à des offres d <?php echo e("'"); ?>emploi et de stages offerte par des entreprises
                    dont vous avez toujours rêver. Allez faites le grand pas et aquérer de l <?php echo e("'"); ?>expérience
                    professionnel afin d <?php echo e("'"); ?>être fier de votre CV.
                </p>
                <a href="">Plus</a>
            </div>
        </div>
        

        
        <div class="slider slide2">
            <div class="info">
                <h2>OSEZ Vous Exprimer et laisser opérer votre créativité.</h2>
                <p>
                    Retrouvez le sourire en saisissant les opportunités qui se présente à vous.
                    Laissez parler votre savoir faire et donnez vous toutes les chances de décrocher un emploi bien
                    rémunéré.
                </p>
                <a href="">Plus</a>
            </div>
        </div>
        

        
        <div class="slider slide3">
            <div class="info">
                <h2>OSEZ Vous Exprimer et laisser opérer votre créativité.</h2>
                <p>
                    Retrouvez le sourire en saisissant les opportunités qui se présente à vous.
                    Laissez parler votre savoir faire et donnez vous toutes les chances de décrocher un emploi bien
                    rémunéré.
                </p>
                <a href="">Plus</a>
            </div>
        </div>
        

    </header>
    

    

    <div id="main">

        
        <section>
            <h1><strong>Les actualités</strong></h1>
            <div class="actu">
                <div class="actu1">
                    <div class="illustration illustration1">
                        <img src=" <?php echo e(asset('img/accueil/header5.jpg')); ?> " width="100%" height="100%" alt="">
                    </div>
                    <div class="description">
                        <p><span class="title">Info</span></p>
                        <p class="text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quo similique illum laborum aliquid esse sunt nesciunt unde sequi voluptas sed explicabo eaque cumque, eum reprehenderit perspiciatis atque? Rem, a consequatur.</p>
                        <a href="">Lire tout</a>
                    </div>
                </div>
                <div class="actu2">
                    <div class="info info1">
                        <p><img src=" <?php echo e(asset('img/da-cruz-recteur-uac-2017.jpg')); ?> " alt="Recteur UAC"></p>
                        <div>
                            <h3>Recteur UAC</h3>
                            <p><strong class="vert">da-CRUZ Rony</strong>, consectetur adipisicing elit. At dolores laudantium recusan</p>
                        </div>
                    </div>
                    <div class="info info2">
                        <p><img src=" <?php echo e(asset('img/patrice-talon.png')); ?> " alt="Patrice Talon Chef du gouvernent"></p>
                        <div>
                            <h3>Chef du gouvernement</h3>
                            <p><strong class="vert">Patrice Atanase Guillaume TALON</strong>, consectetur adipisicing elit. At dolores laudantium recusan</p>
                        </div>
                    </div>
                    
                </div>
                
            </div>
        </section>

        
        <section class="otherversion">
            <h1><strong>Stages et Emplois</strong></h1>
            <div class="splide" data-splide='{"type":"loop","perPage":3,"autoplay":"true","interval":3000,"perMove":1}'>
                <div class="splide__track">
                    <ul class="splide__list" id="offre">
                        <?php $__currentLoopData = $offres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($offre->etat): ?>
                            <li class="splide__slide">
                                <h1> <?php echo e($offre->type); ?> </h1>
                                <p class="affiche">
                                    <img src=" <?php echo e(asset('img/accueil/5fd4e464b3b3c.jpg')); ?> "/>
                                </p>
                                <p>Date : <?php echo e($offre->updated_at); ?> <br> Domaine : <?php echo e($offre->domaine); ?></p>
                                <a href=" <?php echo e(route('offre')); ?> ">Voir</a>
                            </li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>

        </section>



        
        <section>
            <h1><strong>Evènement</strong></h1>
            <div id="evenement">
                <h1>NOËL</h1>
                <p>JOYEUX NOËL A TOUTES ET A TOUS</p>
            </div>
        </section>

        
        <section>
            <h1><strong>PARTENAIRES</strong></h1>

            </section>
        </section>

    </div>

    

    

    <div id="nav">
        <i class="icon-close"></i>
        <ul>
            <li><a class="active" href=" <?php echo e(route('accueil')); ?> ">Accueil</a></li>
            <li><a href=" <?php echo e(route('offre')); ?> ">Opportunités</a></li>
            <li><a href=" <?php echo e(route('ressource')); ?>  ">Ressources Educatives</a></li>
            <li><a href="" id="partenaire">Partenaire</a></li>
            <li><a href="  ">Contact</a></li>
            <li><a href="  ">A propos</a></li>
            <?php if(Auth::check()): ?>
                <li><a href=" <?php echo e(route('logout')); ?> ">Deconnexion</a></li>
            <?php else: ?>
                <li><a href=" <?php echo e(route('login')); ?> ">Connexion</a></li>
            <?php endif; ?>
        </ul>
    </div>

    


    

    <footer>
        Copyright Job-UAC 2020 Tout Droit réservé
    </footer>

    
    <div id="flag">
        <p class="green"></p>
        <p class="yellow"</p>
        <p class="red"></p>
    </div>

    <script src=" <?php echo e(asset('js/slide.js')); ?> "></script>
    <script src=" <?php echo e(asset('js/nav.js')); ?> "></script>
    <script src=" <?php echo e(asset('js/splide.min.js')); ?> "></script>
    <script src=" <?php echo e(asset('js/jquery.min.js')); ?> "></script>
    <script>
        var splide = new Splide( '.splide' );

        splide.on( 'autoplay:play', function ( rate ) {
            console.log( rate ); // 0-1
        } );

        splide.mount();
    </script>
    </body>
</html>
<?php /**PATH P:\uac-job\resources\views/accueil.blade.php ENDPATH**/ ?>