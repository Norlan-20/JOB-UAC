

<?php $__env->startSection('title', 'Activer Compte'); ?>

<?php $__env->startSection('maincontent'); ?>

    <div class="offre2">
        <h2>Activer une offre</h2>
        <table>
            <tr>
                <th>Offre</th>
                <th>Domaine</th>
                <th>Employeur</th>
                <th>Duree</th>
                <th>Etat</th>
                <th>Date</th>
                <th>Activer</th>
            </tr>
            <?php $__currentLoopData = $offres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e($offre['type']); ?> </td>
                    <td> <?php echo e($offre['domaine']); ?> </td>
                    <td> <?php echo e($offre['employeur']); ?> </td>
                    <td> <?php echo e($offre['duree']); ?> </td>
                    <td>
                        <?php if($offre['etat']): ?>
                            Actif
                        <?php else: ?>
                            Inactif
                        <?php endif; ?>
                    </td>
                    <td> <?php echo e($offre['updated_at']); ?> </td>
                    <td> <a href=" <?php echo e(route('activationoffre',['id'=>$offre['id']])); ?> "> <i class="icon-build"></i> </a> </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH P:\uac-job\resources\views/pages/activeoffre.blade.php ENDPATH**/ ?>