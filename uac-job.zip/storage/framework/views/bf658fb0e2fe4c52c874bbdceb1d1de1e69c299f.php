

<?php $__env->startSection('title', 'Activer Compte'); ?>

<?php $__env->startSection('maincontent'); ?>

    <div class="offre2">
        <h2>Activer un compte</h2>
        <table>
            <tr>
                <th>Compte</th>
                <th>Nom</th>
                <th>E-mail</th>
                <th>Etat</th>
                <th>Activer</th>
            </tr>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e($user['type']); ?> </td>
                    <td> <?php echo e($user['name']); ?> </td>
                    <td> <?php echo e($user['email']); ?> </td>
                    <td>
                        <?php if($user['etat']): ?>
                            Actif
                        <?php else: ?>
                            Inactif
                        <?php endif; ?>
                    </td>
                    <td> <a href=" <?php echo e(route('activationcompte',['id'=>$user['id']])); ?> "> <i class="icon-build"></i> </a> </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH P:\uac-job\resources\views/pages/activecompte.blade.php ENDPATH**/ ?>