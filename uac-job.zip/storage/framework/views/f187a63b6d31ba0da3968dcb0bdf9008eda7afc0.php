,ocnvmrldfmkngckdnkcnjgdvjn
<?php /**PATH P:\uac-job\resources\views/offres.blade.php ENDPATH**/ ?>