    
    <nav class="main-nav">
        <h3><a href="<?php echo e(route('accueil')); ?>">UAC-Job</a></h3>
        <div class="link">
            <a class="active" href=" <?php echo e(route('accueil')); ?> ">Accueil</a>
            <a href=" <?php echo e(route('offre')); ?> ">Opportunités</a>
            <a href=" <?php echo e(route('ressource')); ?>  ">Ressources Educatives</a>
            <a href="" id="partenaire">Partenaire</a>
            <a href="  ">Contact</a>
            <a href="  ">A propos</a>
            <?php if(Auth::check()): ?>
                <a href=" <?php echo e(route('logout')); ?> ">Deconnexion</a>
            <?php else: ?>
                <a href=" <?php echo e(route('login')); ?> ">Connexion</a>
            <?php endif; ?>

        </div>
        <div class="shownav"><i class="icon-menu"></i></div>
    </nav>
    
<?php /**PATH P:\uac-job\resources\views/template/nav.blade.php ENDPATH**/ ?>