<?php $result = session('user'); ?>
<?php if(Auth::check() && $result[0]['type']=='Admin'): ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href=" <?php echo e(asset('css/dashboard.css')); ?> ">
    <link rel="stylesheet" href=" <?php echo e(asset('css/font.css')); ?> ">
    <link rel="stylesheet" href=" <?php echo e(asset('font/icomoon/style.css')); ?> ">
    <title>Admin Panel | <?php echo $__env->yieldContent('title'); ?></title>
</head>

<?php
    $etudiant = App\Models\User::where('type','Etudiant')->count();
    $employeur = App\Models\User::where('type','Employeur')->count();
    $stage = App\Models\Offre::where('type','Stage')->count();
    $emploi = App\Models\Offre::where('type','Emploi')->count();
?>
<body>
    <main>
        <div>
            <ul>
                <li><a href=" <?php echo e(route('adminoffre')); ?> "><i class="icon-add_circle"></i> Offre</a></li>
                <li><a href=" <?php echo e(route('adminactualite')); ?> "><i class="icon-add_circle"></i> Actualité</a></li>
                <li><a href=" <?php echo e(route('activeroffre')); ?> "><i class="icon-check-circle-o"></i> Activer une offre</a></li>
                <li><a href=" <?php echo e(route('activercompte')); ?> "><i class="icon-check-circle-o"></i> Activer un compte</a></li>
                <li><a href=""><i class="icon-message"></i> Chat</a></li>
                <li><a href=""><i class="icon-message"></i> Newsletter</a></li>
                <li><a href=""><i class="icon-settings"></i> Outils</a></li>
            </ul>
            <p><a href=" <?php echo e(route('logout')); ?> "><i class="icon-power-off"></i> Deconnexion</a></p>
        </div>
        <div>
            <div class="barre">
                <i class="icon-search"></i>
               <p> <i class="icon-user-o"></i> Admin User</p>
            </div>
            <div class="stat">
                <div id="etudiant">
                    <p><i class="icon-user"></i>Etudiant</p>
                    <p> <?php echo e($etudiant); ?> </p>
                </div>
                <div id="employeur">
                    <p><i class="icon-group"></i>Employeur</p>
                    <p> <?php echo e($employeur); ?> </p>
                </div>
                <div id="stage">
                    <p><i class="icon-assignment_ind"></i>Stage</p>
                    <p> <?php echo e($stage); ?> </p>
                </div>
                <div id="emploi">
                    <p><i class="icon-briefcase"></i>Emploi</p>
                    <p> <?php echo e($emploi); ?> </p>
                </div>
            </div>

            <div id="body">
                <div>
                    <?php echo $__env->yieldContent('maincontent'); ?>
                </div>
            </div>
        </div>
    </main>

        <?php echo $__env->yieldContent('js'); ?>

</body>
</html>

<?php else: ?>
    <?php echo redirect()->route('accueil'); ?>

<?php endif; ?>
<?php /**PATH P:\uac-job\resources\views/template/admin.blade.php ENDPATH**/ ?>