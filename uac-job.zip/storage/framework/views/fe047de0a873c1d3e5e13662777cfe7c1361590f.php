<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href=" <?php echo e(asset('css/slider.css')); ?> ">
    <link rel="stylesheet" href=" <?php echo e(asset('css/nav.css')); ?> ">
    <link rel="stylesheet" href=" <?php echo e(asset('css/font.css')); ?> ">
    <link rel="stylesheet" href=" <?php echo e(asset('css/connexion.css')); ?> ">
    <link rel="stylesheet" href=" <?php echo e(asset('font/icomoon/style.css')); ?> ">
    <title>UAC-Job | Connexion</title>
</head>
<body>

    
    <?php echo $__env->make('template.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <main>
        <div id="form-block">
            <div class="form-deco"></div>
            <div class="form-title"><h3>CONNEXION</h3></div>
            <form action=" <?php echo e(route('authentication')); ?> " method="post">

                <div>
                    <div class="input">
                        <?php echo csrf_field(); ?>
                        <label for="mail"><i class="icon-mail_outline"></i></label>
                        <input type="email" name="mail" id="mail" placeholder="Entrez votre adresse mail">
                    </div>
                </div>
                <div>
                    <div class="input">
                        <label for="pass"><i class="icon-key"></i></label>
                        <input type="password" name="pass" id="pass" placeholder="Entrez votre mot de passe">
                        <?php $__errorArgs = ['pass'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div>
                    <button type="submit">Se connecter</button><br>
                    <p><a href="">Mot de passe oublié</a></p>
                </div>
                <div><p class="inscription">S'inscrire'<i class="icon-arrow-right"></i></p></div>
            </form>
        </div>

        <div id="form-block1" style="display: none;">
            <div class="form-deco"></div>
            <div class="form-title"><h3>INSCRIPTION</h3></div>
            <form action=" <?php echo e(route('register')); ?>  " method="post">

                <div>
                    <div class="input">
                        <?php echo csrf_field(); ?>
                        <label for="name"><i class="icon-user-o"></i></label>
                        <input type="text" name="name" id="name" placeholder="Entrez votre nom et prénoms">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div>
                    <div class="input">
                        <label for="mail"><i class="icon-mail_outline"></i></label>
                        <input type="email" name="mail" id="mail" placeholder="Entrez votre adresse email">
                        <?php $__errorArgs = ['mail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div>
                    <div class="input">
                        <label for="type"><i class="icon-user-secret"></i></label>
                        <select name="type" id="type">
                            <option value="Etudiant">Etudiant</option>
                            <option value="Employeur">Employeur</option>
                        </select>
                    </div>
                </div>
                <div>
                    <div class="input">
                        <label for="pass"><i class="icon-key"></i></label>
                        <input type="password" name="pass1" id="pass" placeholder="Entrez votre mot de passe">
                        <?php $__errorArgs = ['pass1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div>
                    <div class="input">
                        <label for="pass2"><i class="icon-key"></i></label>
                        <input type="password" name="pass2" id="pass2" placeholder="Confirmer votre mot de passe">
                        <?php $__errorArgs = ['pass2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div>
                    <button type="submit">S'inscrire'</button><br>
                </div>
                <div><p class="connexion">Se connecter <i class="icon-arrow-right"></i></p></div>
            </form>
        </div>
    </main>


    

    <div id="nav">
        <i class="icon-close"></i>
        <ul>
            <li><a class="active" href=" <?php echo e(route('accueil')); ?> ">Accueil</a></li>
            <li><a href=" <?php echo e(route('offre')); ?> ">Opportunités</a></li>
            <li><a href=" <?php echo e(route('ressource')); ?>  ">Ressources Educatives</a></li>
            <li><a href="" id="partenaire">Partenaire</a></li>
            <li><a href="  ">Contact</a></li>
            <li><a href="  ">A propos</a></li>
            <?php if(Auth::check()): ?>
                <li><a href=" <?php echo e(route('logout')); ?> ">Deconnexion</a></li>
            <?php else: ?>
                <li><a href=" <?php echo e(route('login')); ?> ">Connexion</a></li>
            <?php endif; ?>
        </ul>
    </div>

    


    <script src=" <?php echo e(asset('js/nav.js')); ?> "></script>

    <script>
        let connexion = document.querySelector('.connexion'),
            inscription = document.querySelector('.inscription');

        inscription.addEventListener('click',showInscriptionForm);
        connexion.addEventListener('click',showConnexionForm);

        function showInscriptionForm(e) {
            document.querySelector('#form-block').style.display="none";
            document.querySelector('#form-block1').style.display="flex";
        }

        function showConnexionForm(e) {
            e.preventDefault();
            document.querySelector('#form-block1').style.display="none";
            document.querySelector('#form-block').style.display="flex";
        }

    </script>

</body>
</html>
<?php /**PATH P:\uac-job\resources\views/pages/connexion.blade.php ENDPATH**/ ?>