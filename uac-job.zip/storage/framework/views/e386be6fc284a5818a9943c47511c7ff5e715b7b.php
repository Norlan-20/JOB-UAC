

<?php $__env->startSection('title', 'Offre'); ?>

<?php $__env->startSection('maincontent'); ?>
    <div>
        <button>Ajouter une actualité</button>
        <button>Modifier une actualité</button>
        <button>Supprimer une actualité</button>
    </div>

    <div></div>
    <div></div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH P:\uac-job\resources\views/pages/adminactualite.blade.php ENDPATH**/ ?>