<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href=" <?php echo e(asset('css/font.css')); ?> ">
    <link rel="stylesheet" href=" <?php echo e(asset('css/nav.css')); ?> ">
    <link rel="stylesheet" href=" <?php echo e(asset('css/slider.css')); ?> ">
    <link rel="stylesheet" href=" <?php echo e(asset('css/offre.css')); ?> ">
    <link rel="stylesheet" href=" <?php echo e(asset('font/icomoon/style.css')); ?> ">
    <title>UAC-Job | Opportunités</title>
</head>
<body>

    <?php echo $__env->make('template.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    

    <header>
        <h1>Stage / Emploi</h1>
    </header>

    

    <div class="para">
        <p>Stage / Emploi</p>
    </div>

    <main>

        <?php $__currentLoopData = $offres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($offre->etat): ?>
                <div class="card">
                    <div>
                        <p> <img src=" <?php echo e(asset('img/accueil/header1.jpg')); ?> " alt=""> </p>
                        <h1> <?php echo e($offre->type); ?> </h1>
                        <h2><i class="icon-domain"></i> <?php echo e($offre->employeur); ?> </h2>
                        <p class="desc"> <?php echo e($offre->description); ?> </p>
                        <p class="hours"><i class="icon-timelapse"></i> <?php echo e($offre->updated_at); ?> </p>
                    </div>
                    <div>
                        <a href="">Postuler</a>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        

    </main>

    

    <div id="nav">
        <i class="icon-close"></i>
        <ul>
            <li><a class="active" href=" <?php echo e(route('accueil')); ?> ">Accueil</a></li>
            <li><a href=" <?php echo e(route('offre')); ?> ">Opportunités</a></li>
            <li><a href=" <?php echo e(route('ressource')); ?>  ">Ressources Educatives</a></li>
            <li><a href="" id="partenaire">Partenaire</a></li>
            <li><a href="  ">Contact</a></li>
            <li><a href="  ">A propos</a></li>
            <?php if(Auth::check()): ?>
                <li><a href=" <?php echo e(route('logout')); ?> ">Deconnexion</a></li>
            <?php else: ?>
                <li><a href=" <?php echo e(route('login')); ?> ">Connexion</a></li>
            <?php endif; ?>
        </ul>
    </div>

    

    <script src=" <?php echo e(asset('js/nav.js')); ?> "></script>
</body>
</html>
<?php /**PATH P:\uac-job\resources\views/pages/offres.blade.php ENDPATH**/ ?>